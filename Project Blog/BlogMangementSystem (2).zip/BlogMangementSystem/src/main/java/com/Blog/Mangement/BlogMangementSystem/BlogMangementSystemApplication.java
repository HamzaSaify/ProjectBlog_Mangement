package com.Blog.Mangement.BlogMangementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogMangementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogMangementSystemApplication.class, args);
	}

}
